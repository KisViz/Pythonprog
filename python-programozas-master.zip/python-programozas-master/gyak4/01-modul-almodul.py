import almodul.kiscica

print(almodul.kiscica.nyavogas(10))
