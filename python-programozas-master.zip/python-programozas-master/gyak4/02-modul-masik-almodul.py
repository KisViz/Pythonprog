import masik_almodul

# Teljes elérési útvonala az adott függvénynek
print(masik_almodul.random_dolgok.random_sor())

# Az __init__.py miatt így, röviden is elérhetjük
print(masik_almodul.random_sor())

print(masik_almodul.random_szerencseszam_generator())
print(masik_almodul.random_szerencseszam())
print(masik_almodul.random_szerszam())
