def nyavogas(alkalom=8):
    return "Miau " * alkalom
