
def copy_list(a_list):
    """
    Copies a list
    :param a_list: a list to be copied
    :return: a shallow copy
    """
    return a_list[:]
