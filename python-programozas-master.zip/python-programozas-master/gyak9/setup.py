from setuptools import setup, find_packages

setup(
    name='python-programozas-gyak9',
    version='',
    packages=find_packages(exclude=("tests",)),
    url='',
    license='',
    author='antalg',
    author_email='',
    description=''
)
