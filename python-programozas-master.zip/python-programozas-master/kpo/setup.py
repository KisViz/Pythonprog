from setuptools import setup, find_packages

setup(
    name='kpo',
    version='',
    packages=find_packages(exclude=("tests")),
    url='',
    license='',
    author='antalg',
    author_email='',
    description=''
)
